<?php
for($i=0;$i<5;$i++){
?>

<div class ="<?php echo (($i+1)%2==0)?"rightbox":"leftbox"; ?>" >
	<h3>Druga pobjeda u nizu</h3>
	<img src="images/druga_pobjeda_u_nizu.jpg" width="300" height="100">
	<p>Fudbaleri Spartak Ždrepčeve krvi ostvarili su dugu pobedu u nizu. Nakon Radničkog u Nišu savladali su Rad golovima na početku i na samom kraju utakmice.  Đuričin je mrežu pogodio u 2. minutu a Shimura u sudijskoj nadoknadi u 92 minutu. </p>
</div>



<?php
}
?>

<footer id= "footer">
			
</footer>


<?php

/*
<div class ="leftbox" >
	<h3>Druga pobjeda u nizu</h3>
	<img src="images/druga_pobjeda_u_nizu.jpg" width="300" height="100">
	<p>Fudbaleri Spartak Ždrepčeve krvi ostvarili su dugu pobedu u nizu. Nakon Radničkog u Nišu savladali su Rad golovima na početku i na samom kraju utakmice.  Đuričin je mrežu pogodio u 2. minutu a Shimura u sudijskoj nadoknadi u 92 minutu. </p>
</div>
			
<div class ="rightbox">
	<h3>Finis koban po velikana</h3>
	<img src="images/finis_koban_po_velikana.jpg" width="300" height="100">
	<p>Borac je poražen (0:2) u Doboju kod Kaknja od Mladosti u utakmici 24. kola Lige za opstanak, bio je ovo duel trenutno dve prvoplasirane ekipe u mini-ligi, a debi na klupi kao šef stručnog štaba, doduše u zvanični zapisnik prijavljen kao službeni predstavnik, imao je mladi sručnjak Marko Maksimović. Bivši fudbaler Banjalučana i mladi reprezentativac BiH.</p>
</div>
			
<div class ="leftbox">
	<h3>Porodila se Ana Ivanovic</h3>
	<img src="images/ana_ivanovic.jpg" width="300" height="100">
	<p>Ana i njen suprug bivši njemački reprezentativac Bastijan Švajnštajger sinu su dali ime Luka, prenose svjetski mediji. Beba i mama odlično se osjećaju, a u Čikago su stigli svi članovi porodice Švajnštajger-Ivanović.Ana i Bastijan vjenčali su se u julu 2016. godine u Veneciji</p>
</div>
			
<div class ="rightbox">
	<h3>Igokea sigurno protiv Sirokog</h3>
	<img src="images/igokea_siroki.jpg" width="300" height="100">
	<p>Košarkaši Igokee pobjedom su otvorili Ligu za prvaka Bosne i Hercegovine. Aleksandrovčani su na svom terenu savladali Široki, rezultatom 91-63.Igokeu je do pobjede predvodio Ponjavić sa 14 poena dok su Jevtović i Ljubičić dodali po 13. Najefikasniji u redovima Širokog bio je Makon sa 18 poena.</p>
</div>
			
<div class ="leftbox">
	<h3>Krece plej of za odbojkasice</h3>
	<img src="images/plej_of_za_odbojkasice.jpg" width="300" height="100">
	<p>Posle odigranog završnog finalnog turnira Kupa BiH pred nama su nova odbojkaška uzbuđenja. U petak i subotu prvim četvrtfinalnim mečevima plej ofa nastavlja se doigravanje za prvaka BiH.
	Igra se do dvije pobjede, a eventualno u trećoj odlučujućoj utakmici prednost domaćeg terena biće na strani boljeplasiranog sa premijerligaške tabele.
	Titulu brani Žok "Bimal jedinstvo" iz Brčkog, a evo i satnice prvih četvrtfinalnih mečeva u konkurenciji odbojkašica.</p>
</div>
			
<div class ="rightbox">
	<h3>Japanac izbacio Novaka</h3>
	<img src="images/novak_djokovic.jpg" width="300" height="100">
	<p>Srpski teniser Novak Đoković nije uspeo da se plasira u treće kolo mastersa u Indijan Velsu, pošto je izgubio od Japanca Tara Danijela sa 6:7, 6:4, 1:6.Đoković je u šestom gemu duplom servis greškom poklonio novi brejk Danijelu, a japanski teniser je u narednom gemu potvrdio svoj najveći trijumf u karijeri.</p>
</div>
	
<div class ="leftbox">
	<h3>Federer nakon pet setova do dvadesete GS titule</h3>
	<img src="images/federer.jpg" width="300" height="100">
	<p>Švajcarac Rodžer Federer pobjedom nad marinom Čilićem iz Hrvatske sa 3:2 (6:2, 6:7, 6:3, 3:6, 6:1) odbranio je titulu na Australijan openu i tako stigao do dvadeste grend slem titule.Pobjednik je riješen brejkom Rodžera u šestom gemu, trećeg seta.Imao je Čilić i dvije šanse za brejk na samom startu petog seta, ali to mu nije uspjelo i vjerovatno ga i koštalo trofeja. Federer se vratio u ritam, prije svega psihički i sa laganih 6:1 u trećem setu stigao do šeste titule u Melburnu, a dvadesete na Grend slem turnirima.</p>
</div>
			
<div class ="rightbox">
	<h3>Euroliga: Zvezda sigurna protiv Valensije</h3>
	<img src="images/zvezda_valensija.jpg" width="300" height="100">
	<p>Košarkaši Crvene zvezde upisali su 11. pobjedu u Eveoligi. Crveno-beli su večeras slavili u Beogradu protiv Valensije, rezultatom 106-88.Zvezdu je do pobjede predvodio Feldin sa 30 poena, dok je Rafa Martinez imao 22 poena i bio najbolji kod gostiju.</p>
</div>
				
			
	
		
		<!--
		<aside id= "sidebar">
			<h3>Ostali podaci:</h3>
			<p>Vremenska zona: UTC+1 (CET), ljeti UTC+2 (CEST)</p>
			<p>Poštanski broj: 71123</p>
			<p>Pozivni broj: 057</p>
			<p>Krsna slava: Sveti Petar Sarajevski</p>
			<br>
			<p><img src= "images/grb1.png" alt= "grb"></p>
			<p> <em>Slika 1 - grb Istočnog Sarajeva</em></p>
			<br>
			<p><img src= "images/zastava2.png" alt= "zastava"></p>
			<p> <em>Slika 2 - zastava Istočnog Sarajeva</em></p>
		</aside>
		-->

		<footer id= "footer">
			
		</footer>

		*/