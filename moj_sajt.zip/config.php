<?php
define("DB","vijesti");
define("DBHOST","localhost");
define("DBUSER","root");
define("DBPASS","");
?>
